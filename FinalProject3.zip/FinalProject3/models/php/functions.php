<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This is the primary functions file, providing the code for all functions called in the application. -->

<?php
    require "../env.php";

    // Function for establishing connecting to a MySQL database
    function dbConnect(){
        $mysqli = new mysqli(SERVER, USERNAME, PASSWORD, DATABASE);
        if($mysqli ->connect_errno != 0){
            return FALSE;
        }else{
            return $mysqli;
        }
    }

    /* Function for retrieving a list of distinct car makes from the products table, 
    storing them in an array, and then returning the array containing the list of car makes. */
    function getMake(){
        $mysqli = dbConnect();
        $result = $mysqli ->query("SELECT DISTINCT Make FROM products");
        while($row = $result ->fetch_assoc()){
            $Make[] = $row;
        }

        return $Make;
    }

    /* Function for retrieveing a specified number of random products from the products table, 
    storing them in an array, and then returning the array containing the product data, for use on the home page. */
    function getHomeProducts($int){
        $mysqli = dbConnect();
        $result = $mysqli ->query("SELECT * FROM  products ORDER BY rand() LIMIT $int");
        while ($row = $result -> fetch_assoc()){
            $data[] = $row;
        }

        return $data;
    }

    /* Function that prepares and executes a SQL query to select all products from the products table where the make matches 
    the provided input, then fetches the results and returns them as an associative array containing the product data.*/
    function getProductsByMake($make){
        $mysqli = dbConnect();

        $smtp = $mysqli -> prepare("SELECT * FROM products WHERE Make = ?");
        $smtp -> bind_param("s", $make);
        $smtp -> execute();
        $result = $smtp -> get_result();
        $data = $result -> fetch_all(MYSQLI_ASSOC);
        return $data;
    }

    /* Function that registers a new user by validating input such as email, username, password, and confirming the password. 
    It checks if the username already exists, ensures that passwords match, hashes the password for security, 
    and inserts the user's information into the users table.*/
    function register($email, $username, $password, $confirmPass){
        $mysqli = dbConnect();
        $args = func_get_args();

        $args = array_map(function($value){
            return trim($value);
        }, $args);

        foreach ($args as $value){
            if(empty($value)){
                return "All fields required";
            }
        }

        $stmt = $mysqli -> prepare("SELECT username FROM users WHERE username = ?");
        $stmt -> bind_param("s", $username);
        $stmt -> execute();
        $result = $stmt -> get_result();
        $data = $result->fetch_assoc();
        if($data != NULL){
            return "Username already exists";
        }

        if ($password != $confirmPass){
            return "Passwords don't match";
        }

        $hashed_pass = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $mysqli -> prepare("INSERT INTO users(username, password, email) VALUES(?,?,?)");
        $stmt->bind_param("sss", $username, $hashed_pass, $email);
        $stmt->execute();
        if ($stmt->affected_rows != 1){
            return "An error occurred. Please try again";
        }

        else{
            return "Success";
        }
    }

    /* Function that logs a new user in by first checking if both fields are filled, retrieves the user's info from the table
    based on an inputted username, verifies the password, and then sets a session variable for a logged in user, redirecting
    the user to the account page upon success.*/
    function login($username, $password){
        $mysqli = dbConnect();
        $username = trim($username);
        $password = trim($password);

        if ($username == "" || $password == ""){
            return "Both fields required";
        }

        $sql = "SELECT username, password FROM users WHERE username = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt -> bind_param("s", $username);
        $stmt -> execute();
        $result = $stmt -> get_result();
        $data = $result -> fetch_assoc();
        if ($data == NULL){
            return "Wrong username or password";
        }

        if(password_verify($password, $data["password"]) == FALSE){
            return "Wrong username or password";
        }
        
        $_SESSION["user"] = $username;
        header("location: account.php");
        exit();
    }

    /* Function that destroys the session variable for the logged in user, and then redirects them to the login page. */
    function logout(){
        session_destroy();
        header("location: login.php");
        exit();
    }

    /* Function for deleting a user's account by preparing an SQL statement to delete the user's record from the users table,
    destroys the session varaible, and then redirects the user to the homepage.*/
    function deleteAccount(){
        $mysqli = dbConnect();

        $sql = "DELETE FROM users WHERE username = ?";
        $stmt = $mysqli -> prepare($sql);
        $stmt -> bind_param("s", $_SESSION['user']);
        $stmt -> execute();

        if($stmt ->affected_rows != 1){
            return "An error occurred. Please try again";
        }else{
            session_destroy();
            header("location: index.php");
            exit();
        }
    }