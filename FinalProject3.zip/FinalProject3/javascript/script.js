/* Peter Tasy - Final Project - CISC3300 - 4/20/24 
The purpose of this JS file is to dynamically highlight what page the user is on, in the nav bar. */

let navLinks = document.querySelectorAll(".links a");
let bodyID = document.querySelector("body").id;

for (let link of navLinks){
    if (link.dataset.active == bodyID){
        link.classList.add("active");
    }
}

document.addEventListener("DOMContentLoaded", function() {
    let navLinks = document.querySelectorAll(".links a");
    let bodyID = document.querySelector("body").id;

    for (let link of navLinks){
        if (link.dataset.active == bodyID){
            link.classList.add("active");
        }
    }

    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(form);
        // Determine action based on form context
        const action = form.id === 'registerForm' ? 'register' : 'login';
        formData.append('action', action);
        fetch('../controllers/AuthController.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                // handle successful registration/login
                console.log('Success:', data.message);
                // Redirect to account.php
                window.location.href = 'account.php';
            } else {
                // handle errors
                console.error('Error:', data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});




