<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file is the controller for the Make.php file. -->

<?php
    require_once "../models/php/functions.php";

    function make() {
        $cat = urldecode($_GET['Make']);
        $products = getProductsByMake($cat);
        if(isset($_GET['Make'])){     
        }
        // Pass $cat variable to the view
        require_once "../views/Make.php";
    }

    

    make();
?>
