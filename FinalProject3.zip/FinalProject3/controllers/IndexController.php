<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file is the controller for the index.php file. -->

<?php
    require_once "../models/php/functions.php";

    function index() {
        $makes = getMake();
        $products = getHomeProducts(4);

        require_once "../views/index.php";
    }
    index();
?>