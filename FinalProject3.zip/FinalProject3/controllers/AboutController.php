<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file is the controller for the about.php file. -->

<?php
    function about() {
        require_once "../views/about.php";
    }

    about();
?>
