<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file is the controller for the login.php and createAcc.php files. It checks if 
an incoming POST request has an action parameter, and if it does, it executes one of three options. -->

<?php 
require_once "../models/php/functions.php";

if(isset($_POST['action'])) {
    $action = $_POST['action'];
    switch($action) {
        case 'register':
            $response = register($_POST['email'], $_POST['username'], $_POST['password'], $_POST['password2']);
            break;
        case 'login':
            $response = login($_POST['username'], $_POST['password']);
            break;
        default:
            $response = array('success' => false, 'message' => 'Invalid action');
            break;
    }
}


