<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file is the controller for the contact.php file. -->

<?php
    function contact() {
        require_once "../views/contact.php";
    }

    contact();
?>
