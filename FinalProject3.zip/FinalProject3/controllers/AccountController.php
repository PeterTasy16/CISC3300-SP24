<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file is the controller for the account.php file. -->

<?php
    require_once "../models/php/functions.php";

    function account() {
        
        if (!isset($_SESSION["user"])) {
            
            header("Location: login.php");
            exit();
        }

        if(isset($_GET['logout'])){
            logout();
        }
    
        
        if(isset($_GET['delete-account'])){
            deleteAccount();
        }

        require_once "../views/account.php";
    }
    
    account();
?>
