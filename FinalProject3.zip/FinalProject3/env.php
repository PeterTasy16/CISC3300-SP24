<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file creates a user session, needed for the login/logout system,
and passes parameters for accessing the MySQL database. -->

<?php
    session_start();
    define('SERVER', 'localhost');
    define('USERNAME', 'root');
    define('PASSWORD', 'gawiC7ast*');
    define('DATABASE', 'storefront');
?>
