<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file serves as the sign up page for the site. -->

<?php require_once "../controllers/AuthController.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
</head>
<body id="createAcc">

    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>

    <form id="" method="post" autocomplete="off">

        <h2>Sign Up</h2>
        <h4>Fill this in to create an account</h4>

        <!-- Code that creates a sign up form that includes fields for entering an email, username, password, and the password again. -->
        <div class="grid">      
            <div>
                <label>Email *</label>
                <input type="text" name="email">
            </div>

            <div>
                <label>Username *</label>
                <input type="text" name="username">
            </div>

            <div>
                <label>Password *</label>
                <input type="text" name="password">
            </div>

            <div>
                <label>Confirm Password *</label>
                <input type="text" name="password2">
            </div>
        </div>

        <button type="submit">Submit</button>

        <p>
            Already have an account?
            <a href="login.php">Login</a>
        </p>
        <br>

    </form>

    <?php include "styling/footer.php" ?>

    <script src="../javascript/script.js"></script>
    
</body>
</html>
