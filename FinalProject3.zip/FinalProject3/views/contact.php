<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file serves to represent the contact page. -->

<?php require_once "../controllers/ContactController.php"; contact(); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
    <style>
        footer{
            position: fixed;
            bottom: 0;
        }
    </style>
</head>
<body id="contact">
    
    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>

    <main>
        <h2>Contact us</h2><br><br>
        <h3><i>Sorry, this page is under construction</i></h3>
    </main>

    <?php include "styling/footer.php" ?>

    <script src="../javascript/script.js"></script>
</body>
</html>