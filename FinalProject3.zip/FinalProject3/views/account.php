<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file represents the account page. Only logged in users will see it. -->

<?php require_once "../controllers/AccountController.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
</head>
<body id="account">

    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>

    <div class ="page">

    <h2>Welcome <?php echo $_SESSION["user"] ?>!</h2> <!-- PHP code that inserts the user's username, depending on the user's session variable. -->
    <h4>This is your account page</h4>

    <p>
        <i>Functionalities to come.</i>
    </p>
    <br>

    <a href="?logout">Logout</a>
    <a href="?delete-account" style="color: red;" >Delete account</a>


    <?php include "styling/footer.php" ?>

    <script src="../javascript/script.js"></script>
    
</body>
</html>