<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This is the login page file. -->

<?php require_once "../controllers/AuthController.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
</head>
<body id="login">

    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>

    <!-- Code that creates a login form that includes fields for entering a username and password. -->
    <form action = "" method="post" autocomplete="off">

        <h2>Sign in</h2>

        <div class="grid">
            <div>
                <label>Username *</label>
                <input type="text" name="username" value="<?php echo @$_POST['username']; ?>">
            </div>

            <div>
                <label>Password *</label>
                <input type="text" name="password" value="<?php echo @$_POST['[password]']; ?>">
            </div>

        <button type="submit" name="submit">Submit</button>

        <p>
            Need an account?
            <a href ="createAcc.php">Sign up</a>
        </p>
        <br>
        
        <p class="error"><?php echo @$response; ?></p>

    </form>

    <?php include "styling/footer.php" ?>

    <script src="javascript/script.js"></script>
    
</body>
</html>