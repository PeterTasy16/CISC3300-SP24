<footer>
            <a data-active="index" href="index.php">Home</a>
            <a data-active="about" href="about.php">About</a>
            <a data-active="contact" href="contact.php">Contact</a>
            <a data-active="createAcc" href="createAcc.php">Register/Login</a>
    </footer>