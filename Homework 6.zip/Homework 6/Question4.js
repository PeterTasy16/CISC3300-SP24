const $ = require('jquery');
require('jquery-ajax');

const baseURL = 'http://localhost:3000';

// GET request to request data from the "posts" resource
$.GET(`${baseURL}/posts/2`, function(data) 
    {
        console.log('GET Request Result:', data);
    }
    );


 const newData = {
    title: 'New Post Title',
    content: 'Hello World.'
    };
      
// Make a POST request to add a new resource
$.post(`${baseURL}/posts`, newData, function(data) {
    console.log('POST Request Result:', data);
});

