<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
The purpose of this file is to pull from the products table and display/sort the cars
based on their make. -->

<?php require "php/functions.php" ?>
<?php // PHP code that checks if the "Make" parameter is set in the URL. If it is set, it decodes the parameter value and assigns it to the variable $cat.
        $cat = urldecode($_GET['Make']);
    if(isset($_GET['Make'])){     
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
</head>
<body>
    
    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>

    <main>
        <div class="left">
            <div class="section-title">Makes</div>
            <?php $Makes = getMake() ?>
            <?php 
                foreach($Makes as $Make){
                    ?>
                        <a href="Make.php?Make=<?php echo urldecode($Make['Make']) ?>"><?php echo ucfirst($Make['Make'])?>
                        </a>
                    <?php 
                }
            ?>
        </div>
        <div class="right"> <!-- HTML and PHP code that generates product listings based on a specified make ($cat). -->
            <div class="section-title"><?php echo $cat?></div>
            <?php $products = getProductsByMake($cat) ?>
            <div class="product">
                <?php 
                    foreach($products as $product){
                        ?>
                            <div class="product-left">
                                <img src="<?php echo $product['image'] ?>" alt="">
                            </div>
                            <div class="product-right">
                                <p class="title">
                                    <a href="product.php?title=<?php echo urlencode($product['name'])?>">
                                        <?php echo $product['name'] ?>
                                    </a>
                                </p>
                                <p class="description">
                                    <?php echo $product['description'] ?>
                                </p>
                                <p class="price">
                                    <?php echo $product['price'] ?>
                                </p>
                            </div>

                        <?php 
                    }
                ?>
                
            </div>
        </div>
    </main>

    <?php include "styling/footer.php" ?>

    <script src="javascript/script.js"></script>
</body>
</html>