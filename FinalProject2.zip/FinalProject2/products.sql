-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2024 at 02:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `storefront`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `Make` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `Make`) VALUES
(1, '2024 Honda Accord', 'The latest Accord model from Honda, starting at $27,895.', 27895.00, 'products/honda/honda_accord.png', 'Honda'),
(2, '2024 Honda Civic Sedan', 'The latest base model Civic from Honda, starting at $23,950.', 23950.00, 'products/honda/honda_civic.png', 'Honda'),
(3, '2024 Honda Civic Type R', 'The latest Civic Type R model from Honda, starting at $45,890.', 45890.00, 'products/honda/honda_civic_r.png', 'Honda'),
(4, '2024 Honda Pilot', 'The latest Pilot model from Honda, starting at $39,900.', 39900.00, 'products/honda/honda_pilot.png', 'Honda'),
(5, '2024 Toyota Corolla', 'The latest Corolla model from Toyota, starting at $22,050.', 22050.00, 'products/toyota/toyota_corolla.png', 'Toyota'),
(6, '2024 Toyota Camry', 'The latest Camry model from Toyota, starting at $26,420.', 26420.00, 'products/toyota/toyota_camry.png', 'Toyota'),
(7, '2024 Toyota GR86', 'The latest GR86 model from Toyota, starting at $29,300.', 29300.00, 'products/toyota/toyota_gr86.png', 'Toyota'),
(8, '2024 Toyota Tacoma', 'The latest Tacoma model from Toyota, starting at $31,500.', 31500.00, 'products/toyota/toyota_tacoma.png', 'Toyota'),
(9, '2024 Nissan Altima', 'The latest Altima model from Nissan, starting at $26,370.', 26370.00, 'products/nissan/nissan_altima.png', 'Nissan'),
(10, '2024 Nissan Frontier', 'The latest Frontier model from Nissan, starting at $30,510.', 30510.00, 'products/nissan/nissan_frontier.jpg', 'Nissan'),
(11, '2024 Nissan Pathfinder', 'The latest Pathfinder model from Nissan, starting at $36,650.', 36650.00, 'products/nissan/nissan_pathfinder.png', 'Nissan'),
(12, '2024 Nissan GT-R', 'The latest GT-R (R35) model from Nissan, starting at $121,090.', 121090.00, 'products/nissan/nissan_gtr.png', 'Nissan'),
(13, '2024 Ford Bronco', 'The latest Bronco model from Ford, starting at $39,630.', 39630.00, 'products/ford/ford_bronco.jpg', 'Ford'),
(14, '2024 Ford F-150', 'The latest F-150 model from Ford, starting at $36,770.', 36770.00, 'products/ford/ford_f150.png', 'Ford'),
(15, '2024 Ford Explorer', 'The latest Explorer model from Ford, starting at $36,860.', 36860.00, 'products/ford/ford_explorer.jpg', 'Ford'),
(16, '2024 Ford Mustang', 'The latest Mustang model from Ford, starting at $30,920.', 30920.00, 'products/ford/ford_mustang.png', 'Ford');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
