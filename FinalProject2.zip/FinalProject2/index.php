<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
The purpose of this code is to create a fictional prototype storefront for automobiles.
It accesses two tables in the storefront MySQL database. The first, products, contains
information regarding make, model, price, and a description. The site pulls 4 random entries
from products to display. The second database, users, allows for a login/account/logout system. -->

<?php require "php/functions.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
</head>
<body id="index">
    
    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>


    <main>
        <div class="left">                    <!-- HTML and PHP code for construction of left hotbar. -->
            <div class="section-title">Makes</div>
            <?php $Makes = getMake() ?>
            <?php 
                foreach($Makes as $Make){
                    ?>
                        <a href="Make.html?Make=<?php echo urldecode($Make['Make']) ?>"><?php echo ucfirst($Make['Make'])?>
                        </a>
                    <?php 
                }
            ?> 
        </div>
        <div class="right">    <!-- HTML and PHP code for construction of main page. It displays 4 random entries from the products database. -->
            <div class="section-title">Home page</div>
            <?php $products = getHomeProducts(4) ?>
            <div class="product">
                <?php 
                    foreach($products as $product){
                        ?>
                            <div class="product-left">
                                <img src="<?php echo $product['image'] ?>" alt="">
                            </div>
                            <div class="product-right">
                                <p class="title">
                                    <a href="product.php?title=<?php echo urlencode($product['name'])?>">
                                        <?php echo $product['name'] ?>
                                    </a>
                                </p>
                                <p class="description">
                                    <?php echo $product['description'] ?>
                                </p>
                                <p class="price">
                                    <?php echo $product['price'] ?>
                                </p>
                            </div>

                        <?php 
                    }
                ?>
                
            </div>
        </div>
    </main>

    <?php include "styling/footer.php" ?>

    <script src="javascript/script.js"></script>
</body>
</html>