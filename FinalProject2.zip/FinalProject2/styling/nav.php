<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file serves to represent the nav bar, providing links to each page. -->

<nav>
        <div class="brand">AutoShop</div>
        <div class="links">
            <a data-active="index" href="index.php">Home</a>
            <a data-active="about" href="about.php">About</a>
            <a data-active="contact" href="contact.php">Contact</a>
            <a data-active="createAcc" href="createAcc.php">Register/Login</a>
            <a data-active="account" href="account.php">Account</a>
        </div>
</nav>