<header>
        <h1>Welcome to the best auto shop on the planet!</h1>
        <p class="subtitle">
            Here you'll be able to find all of the best steals and deals on this side of the sun.
        </p>
    </header>