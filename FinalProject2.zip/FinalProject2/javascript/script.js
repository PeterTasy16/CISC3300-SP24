/* Peter Tasy - Final Project - CISC3300 - 4/20/24 
The purpose of this JS file is to dynamically highlight what page the user is on, in the nav bar. */

let navLinks = document.querySelectorAll(".links a");
let bodyID = document.querySelector("body").id;

for (let link of navLinks){
    if (link.dataset.active == bodyID){
        link.classList.add("active");
    }
}