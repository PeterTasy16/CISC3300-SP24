<!-- Peter Tasy - Final Project - CISC3300 - 4/20/24 
This file serves to represent the about page. -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We offer all kinds of makes and models!">
    <meta name="keywords" content="Honda, Toyota, Nissan, Ford, Chevy, Ferrari, BMW">
    <link rel="stylesheet" href="css/styles.css">
    <title>AutoShop</title>
    <style>
        footer{
            position: fixed;
            bottom: 0;
        }
    </style>
</head>
<body id="about">
    
    <?php include "styling/nav.php" ?>
    <?php include "styling/header.php" ?>

    <main>
        <h2>About Us </h2>
        <br><br>
        <p>
            <i>Our office</i><br><br>
            <img src="products/house.jpg" alt="Our office" width="600" height="400">  
        </p>
    </main>

    <?php include "styling/footer.php" ?>

    <script src="javascript/script.js"></script>
</body>
</html>