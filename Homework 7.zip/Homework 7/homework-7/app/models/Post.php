<?php

namespace app\models;

class Post
{

}