<?php

namespace app\models;

use PDO;

class Post
{
    private $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function getAllPosts()
    {
        $statement = $this->pdo->query("SELECT * FROM posts");
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function savePost($title, $description)
    {
        $statement = $this->pdo->prepare("INSERT INTO posts (title, description) VALUES (:title, :description)");
        $statement->execute(['title' => $title, 'description' => $description]);
        return $this->pdo->lastInsertId();
    }

    public function getPostById($id)
    {
        $statement = $this->pdo->prepare("SELECT * FROM posts WHERE id = :id");
        $statement->execute(['id' => $id]);
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    public function updatePost($id, $title, $description)
    {
        $statement = $this->pdo->prepare("UPDATE posts SET title = :title, description = :description WHERE id = :id");
        return $statement->execute(['id' => $id, 'title' => $title, 'description' => $description]);
    }

    public function deletePostById($id)
    {
        $statement = $this->pdo->prepare("DELETE FROM posts WHERE id = :id");
        return $statement->execute(['id' => $id]);
    }
}

